function setup() {
createCanvas(600, 600) //criando o cenário 
 background("white");  // cor do cenário
}

function draw() {  // desempenho do desenho

stroke("#00BCD4"); // coloração do contorno do retângulo
  fill("#E91E63"); // coloração do retângulo

  if (mouseIsPressed) { // quando o mouse for pressionado, o retângulo irá aparecer
    rect(mouseX, mouseY, 20, 35); //posição e tamanho do mouse; mouseY e mouseX é para definir a direção do ponteiro do mouse
  }
}
